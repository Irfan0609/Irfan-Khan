document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("contactForm");

    form.addEventListener("submit", function (event) {
        event.preventDefault();

        if (validateForm()) {
            // If form is valid, submit to Formspree
            form.submit();
        }
    });

    function validateForm() {
        const firstName = document.getElementById("firstName").value.trim();
        const lastName = document.getElementById("lastName").value.trim();
        const email = document.getElementById("email").value.trim();
        const date = document.getElementById("date").value.trim();
        const phone = document.getElementById("phone").value.trim();
        const message = document.getElementById("message").value.trim();

        // Validations
        if (firstName.length < 5) {
            alert("First name should be at least 5 characters.");
            return false;
        }
        if (lastName.length < 5) {
            alert("Last name should be at least 5 characters.");
            return false;
        }
        if (!email.includes("@")) {
            alert("Email should contain '@'.");
            return false;
        }
        if (!validateDate(date)) {
            alert("Date must be in the format dd/mm/yy.");
            return false;
        }
        if (phone.length !== 10) {
            alert("Phone must contain 10 digits.");
            return false;
        }
        if (message.length < 50) {
            alert("Message must be at least 50 characters long.");
            return false;
        }

        return true;
    }

    function validateDate(date) {
        const regex = /^\d{2}\/\d{2}\/\d{2}$/;
        return regex.test(date);
    }
});
